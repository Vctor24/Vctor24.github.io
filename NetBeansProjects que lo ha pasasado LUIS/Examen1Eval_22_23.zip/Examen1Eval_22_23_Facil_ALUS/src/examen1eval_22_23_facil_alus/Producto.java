/*
 * Clase Producto
Campos: - nombre del producto
        - fecha de compra, fecha en la que se compró este producto
        - número de Albarán, donde figura la compra de este producto
        - pvp, precio por unidad
        - unidades de este producto, comprado en la fecha indicada con nº albarán indicado
        - preciototal --> saco el precio total, según el pvp, el nº de unidades 
                y el dto de la tienda y el mes indicado en la fecha
        - Un array bidimensional llamado descuentos que me dice, según el nº de tienda (de 5)
        y el nº de mes, qué descuento se aplica (aleatorio entre 0%, 10%, 20%, 35%, 50%)
 */
package examen1eval_22_23_facil_alus;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;

import java.util.Date;
import javax.swing.text.DateFormatter;

/**
 *
 * @author Rut
 */
public class Producto {
    final byte numTiendas = 15;
    
    private String nombre;
    private LocalDate fecha;
    private String albaran;
    private double pvp;
    private int unidades;
    private double precioTotal;
    private int tienda;
    private int[][] descuentos;

    public Producto(String nombre, String fecha, double pvp, int unidades, int tienda) {
        this.nombre = nombre;
        this.pvp = pvp;
        this.unidades = unidades;
        this.tienda = tienda;
        setFecha(fecha);
        setAlbaran();
        setDescuentos();
        setPrecioTotal();
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    // 1 pto  (setFecha)

    // 1 pto (getFecha)
    

    public String getAlbaran() {
        return albaran;
    }

    
    // 2 ptos
    public void setAlbaran() {
        // El albarán será un String con la fecha + 3 primeros caracteres nombre 
        // + número de la tienda con dos dígitos
       
    }

    public double getPvp() {
        return pvp;
    }

    public void setPvp(double pvp) {
        this.pvp = pvp;
    }

    public int getUnidades() {
        return unidades;
    }

    public void setUnidades(int unidades) {
        this.unidades = unidades;
    }

    public int getTienda() {
        return tienda;
    }

    public void setTienda(int tienda) {
        this.tienda = tienda;
    }

    public double getPrecioTotal() {
        return precioTotal;
    }

    // 2,5 ptos
    public void setPrecioTotal() {
       
    }

    // 2 ptos
    public void setDescuentos() {
        
    }
    
  
    
    public void muestraDescuentos() {
        final int numMeses = 12;
        for (int i = 0; i < numTiendas; i++) {
            System.out.println("Tienda " + i + ": ");
            for (int j = 0; j < numMeses; j++) {
                System.out.print(descuentos[i][j] + " ");
            }
            System.out.println("");
        }
    }

    @Override
    public String toString() {
        return "Producto{Nombre=" + nombre + ", fecha=" + fecha + ", albaran=" 
                + albaran + ", pvp=" + pvp + ", unidades=" + unidades +", "
                + "tienda =" + tienda + ", precioTotal=" + precioTotal + '}';
    }
    
    
}
